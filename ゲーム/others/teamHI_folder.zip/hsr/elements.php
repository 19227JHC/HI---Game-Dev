<!--─────────────────ELEMENTS PAGE────────────────-->

<?php include("topbit.php") ?>

<!--─────────────────Background────────────────-->
<body style="
  background-color: black;
  background-image: url(pictures/bg.jpg);
  background-repeat: no-repeat;
  background-position: center center;
  background-attachment: fixed;
  background-size: cover;">

  <!--────────────────Nav Bar───────────────-->
  <nav>
    <a href="index.php">Home</a>
    <div class="dropdown">
      <button class="dropbtn" style="background-color: #efd59bff; color: black;">Databases 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="characters.php">Characters</a>
        <a href="elements.php">Elements</a>
        <a href="paths.php">Paths</a>
      </div>
    </div>
    <a href="about_us.php">About Us</a>
    <a class="logo" href="https://hsr.hoyoverse.com/en-us/" target="_blank"><img src=pictures/logo.png alt="logo-link" style="height: 15px;"></a>
  </nav>

  <main>
	<!--───────Below Navbar───────-->
    <h2>Honkai: Star-Rail</h2>

    <div class="content">
		
		<?php

			echo '<h1 class="allHeading">Elements List</h1>';

			//Sort//
			require_once 'connect.php';

			if (isset($_REQUEST['sort'])){
					$sort = $_REQUEST['sort'];
			}
			else {
				$sort = 0;
			}

			if ($sort == "1") {
				$sql = "SELECT elements.* FROM elements ORDER BY Element_Name DESC";
			} elseif ($sort == "2") {
				$sql = "SELECT elements.* FROM elements ORDER BY eleID";
			} else {
				$sql = "SELECT elements.* FROM elements ORDER BY Element_Name DESC";
				}


			$result = $conn->query($sql);
			//$sql = "SELECT elements.* FROM elements";//
			//$sql = "SELECT character.*, path.*, element.* FROM character, path WHERE character.Paths = paths.ID, element WHERE characters.Elements = element.ID";

			//Allowing the user to sort your database//
			echo '<div class="row">';
				echo '<div class="col">';
					echo '<form id="sort" action="elements.php" method="post">';
						echo '<select name="sort">';
							echo '<option value="1">Name (Z-A)</option>';
							echo '<option value="2">Element</option>';
						echo '</select>';
						echo '<button type="submit" name="submit" class="btn-primary">Sort</button>';
						echo '<br>';
					echo '</form>';
				echo '</div>';
			echo '</div>';

			echo '<br>';
			
			// The list starts here. The 'Cards' //
			echo '<section id="allList">';
				
				if($result->num_rows > 0){
					while($row = $result->fetch_assoc()){
						echo '<article>';
						
							echo '<h2>' . $row["Element_Name"] . '</h2>';
							echo '<figure><img src=' . $row["Logo"] . ' height="150" width "150"></img></figure>';
							echo '<p><span id="title">Unique Traits: </span><span>' . $row["eleUT"] . '</span></p>';
							echo '<p><span id="title">General Description: </span><span>' . $row["eleGD"] . '</span></p>';
							echo '<p><span id="title">Famous Emanators: </span><span>' . $row["eleFE"] . '</span></p>';
						
						echo '</article>';
					}
				}

			echo '</section>';
		?>
		
	  </div>

  </main>
      
<?php include("bottombit.php") ?>