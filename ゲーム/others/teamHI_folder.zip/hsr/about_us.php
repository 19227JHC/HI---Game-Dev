<!--─────────────────ABOUT US PAGE────────────────-->

<?php include("topbit.php") ?>

<!--─────────────────Background────────────────-->
<body style="
  background-color: black;
  background-image: url(pictures/bg.jpg);
  background-repeat: no-repeat;
  background-position: center center;
  background-attachment: fixed;
  background-size: cover;">

  <!--────────────────Nav Bar───────────────-->
  <nav>
	<a href="index.php">Home</a>
	<div class="dropdown">
	  <button class="dropbtn">Databases 
		<i class="fa fa-caret-down"></i>
	  </button>
	  <div class="dropdown-content">
		<a href="characters.php">Characters</a>
		<a href="elements.php">Elements</a>
		<a href="paths.php">Paths</a>
	  </div>
	</div>
	<a class="active" href="about_us.php">About Us</a>
	<a class="logo" href="https://hsr.hoyoverse.com/en-us/" target="_blank"><img src=pictures/logo.png alt="logo-link" style="height: 15px;"></a>
  </nav>


  <!--───────────────Content───────────────-->

  <div class="row" style="margin-top: 60px;">
    <div class="side">
	  <!-- Slideshow container -->
	  <div class="slideshow-container">

	    <!-- Full-width images with number and caption text -->
	    <div class="mySlides fade">
		  <div class="numbertext">1 / 3</div>
		  <img src="pictures/aventurine.gif" style="width:250px;" alt="Aventurine">
		  <div class="text">All Hail Our Gambling God</div>
	    </div>

	    <div class="mySlides fade">
		  <div class="numbertext">2 / 3</div>
		  <img src="pictures/kururing.gif" style="width:250px;" alt="Herta">
		  <div class="text">The Spinning Meme-Master</div>
	    </div>

	    <div class="mySlides fade">
		  <div class="numbertext">3 / 3</div>
		  <img src="pictures/chars/sampo.png" style="width:250px;" alt="Sampo">
		  <div class="text">No Explanation Needed.</div>
	    </div>
		  
	  </div>
	  <br>

	  <!-- The dots/circles -->
	  <div style="text-align:center">
	    <span class="dot" onclick="currentSlide(1)"></span>
	    <span class="dot" onclick="currentSlide(2)"></span>
	    <span class="dot" onclick="currentSlide(3)"></span>
	  </div>
	</div>

    <div class="main">
	  <h2>HELLO, MY HERD OF NERDS!</h2>
	  <p>Have a feast with the memes we have prepared for thee.</p>
  	  <br>
  	  <br>
	  <br>
	  <p>That's it. This is our about us page.</p>
    </div>
  </div>
      
<?php include("bottombit.php") ?>