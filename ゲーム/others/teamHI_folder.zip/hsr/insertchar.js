 //───────────────Add Form Validation───────────────//

function validateForm() {
	alert("Working!");
	
	var Name = document.getElementById("bname").value;
	alert(Name)
	if(title == ""){
		alert("Name must be filled out!");
		return false;
	}
	var Picture = document.getElementById("bpicture").value;
	alert(Picture)
	if(title == ""){
		alert("Picture must be filled out!");
		return false;
	}
	var Rarity = document.getElementById("brarity").value;
	alert(Rarity)
	if(title == ""){
		alert("Rarity must be filled out!");
		return false;
	}
	var PathsID = document.getElementById("bpath").value;
	alert(PathsID)
	if(title == ""){
		alert("Paths must be filled out!");
		return false;
	}
	var ElementsID = document.getElementById("belements").value;
	alert(ElementsID)
	if(title == ""){
		alert("Elements must be filled out!");
		return false;
	}
	var Skill = document.getElementById("bskill").value;
	alert(Skill)
	if(title == ""){
		alert("Skill must be filled out!");
		return false;
	}
	var Ult = document.getElementById("bult").value;
	alert(Ult)
	if(title == ""){
		alert("Ultimate must be filled out!");
		return false;
	}
	var Talent = document.getElementById("btalent").value;
	alert(Talent)
	if(title == ""){
		alert("Talent must be filled out!");
		return false;
	}
	var charGD = document.getElementById("bcharGD").value;
	alert(charGD)
	if(title == ""){
		alert("General description must be filled out!");
		return false;
	}
	var Trailer_Link = document.getElementById("btrailer_link").value;
	alert(Trailer_Link)
	if(title == ""){
		alert("Trailer link must be filled out!");
		return false;
	}
}