<!DOCTYPE HTML>

<html lang="en">
      
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <!-- Need this for making websites responsive -->
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="description" content="hsr, Honkai: Star-Rail, ">
  <meta name="author" content="Hannah & Irene">
  <meta name="keywords" content="music, singers, ratings">
	
  <!--Styling Files-->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/main.css">    <!-- custom style sheet -->
  <link rel="stylesheet" href="css/responsive.css">    <!-- custom responsive style sheet -->
	
  <!--Javascripts-->
  <script type="text/javascript" src="insertchar.js"></script>

  <!--────────────────Title───────────────-->
  <title>Honkai: Star-Rail</title>
  <link rel="icon" type="image/png" href="pictures/logo.png">
  <!--# try
  #still not working TAT try pressing that new tab in the webview
  
  # ahh think i got it mabye what whattt
  same difference apparently T-T
  thats it imma search it up
  Ai?
  # W3schools
  i think i get it, gimme a moemnt
  k
  #RIp it still doesnt work... ai this time :') Noooooooo
  
  # It like working some of the time this is weirdddddd
  ikrrrr

  # WAIT ITS ON THE HOMe PAGE BUT NOT FOR THE OTHERS so it works
  # well yea man, tis only the home page we've changed. BU ITS THEREE?????? WHY'S MINE NOT THEN??? 
  uhmmm im the choosen one? rip your gone now :(
  
  #DUDE THAT WAS U??? SCARED THE HECK OUT OF ME MAN ADKLSJ:KFDS:JKFJ
  #sorry
  #I MEAN THANK GOD UR NOT A GHOST ToT. now do u know how to make the favicon work?
  #uhm mabye? send help
  # do you have the image for it?
  look in pictures. its a folder. Ahhhh okay-->
  
  <link href="style-home.css" rel="stylesheet" type="text/css" />

  <!--────────────────Favicon───────────────-->
  <!-- Source: https://www.w3schools.com/html/html_favicon.asp -->
  <link rel="icon" type="image/x-icon" href="pictures/logo.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>

