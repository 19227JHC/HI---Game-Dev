<?php					
	
	//connect to database
	require_once 'connect.php';

	$ID = $_REQUEST ['ID'];

	//SQL request
	$sql = "DELETE FROM characters WHERE ID = '" . $ID . "'";

		if (mysqli_query ($conn,$sql)) {  
			print ("Deleted");
		}
		else{
			print ("Failed");
		}
		
	// open the page that has the database on
		echo "<script>location.href='confirm_delete.php'</script>";
?>
