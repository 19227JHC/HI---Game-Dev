      <!--────────────────Footer-───────────────-->
  <footer>
    <center>
      <p>By: Hannah Wilson & Irene Tendean</p>
      <p>Email: dont.ask.we.forgot@school.com</p>
    </center>
  </footer>
</body>

</html>