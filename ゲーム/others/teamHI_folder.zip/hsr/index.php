<!--─────────────────HOME PAGE────────────────-->

<?php include("topbit.php") ?>

<!--─────────────────Background────────────────-->
<body style="
  background-color: black;
  background-image: url(pictures/bg.jpg);
  background-repeat: no-repeat;
  background-position: center center;
  background-attachment: fixed;
  background-size: cover;">

  <!--────────────────Nav Bar───────────────-->
  <nav>
	<a class="active" href="index.php">Home</a>
	<div class="dropdown">
	  <button class="dropbtn">Databases 
		<i class="fa fa-caret-down"></i>
	  </button>
	  <div class="dropdown-content">
		<a href="characters.php">Characters</a>
		<a href="elements.php">Elements</a>
		<a href="paths.php">Paths</a>
	  </div>
	</div>
	<a href="about_us.php">About Us</a>
	<a class="logo" href="https://hsr.hoyoverse.com/en-us/" target="_blank"><img src=pictures/logo.png alt="logo-link" style="height: 15px;"></a>
  </nav>

  <!--───────────────Content───────────────-->
  <div class="content-index" style="right: 10px; bottom: 10px; position: fixed; z-index: 3;">
	<h1>Honkai: Star-Rail</h1>
	<p>Welcome to Nerd Haven. <br> We welcome all nerds (no destroying our hard work though, and please be serious about this like us :).</p>
  </div>
      
<?php include("bottombit.php") ?>