<?php
	//PRINT A STATMENT THAT INPUT HAS BEEN LOADED INTO DATABASE
	print("<h2>Loaded</h2>");

	//CONNECT TO OUR DATABASE
	require_once ('connect.php');

	$Name = mysqli_real_escape_string($conn,$_REQUEST ['bname']);
	$Picture = $_REQUEST ['bpicture'];
	$Rarity = $_REQUEST ['brarity'];
	$PathsID = $_REQUEST ['bpath'];
	$ElementsID = $_REQUEST ['belements'];
	$Skill = mysqli_real_escape_string($conn,$_REQUEST ['bskill']);
	$Ult = mysqli_real_escape_string($conn,$_REQUEST ['bult']);
	$Talent = mysqli_real_escape_string($conn,$_REQUEST ['btalent']);
	$charGD = mysqli_real_escape_string($conn,$_REQUEST ['bcharGD']);
	$Trailer_Link = mysqli_real_escape_string($conn,$_REQUEST ['btrailer_link']);

	$sql = "INSERT INTO characters (Name, Picture, Rarity, PathsID, ElementsID, Skill, Ult, Talent, charGD, Trailer_Link)
			VALUES ('$Name', '$Picture', '$Rarity', '$PathsID', '$ElementsID', '$Skill', '$Ult', '$Talent', '$charGD', '$Trailer_Link')";

	if ($conn->query($sql) == true){
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	echo "<script>location.href='characters.php'</script>";
?>

